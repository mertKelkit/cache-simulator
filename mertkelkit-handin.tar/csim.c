/*
	Mert KELKİT
	1501153013
	Project 3
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include "cachelab.h"

#define Address unsigned long long int

typedef struct line
{
	Address tagBit;
	int validBit;
	int lru;
	int isFull;
} Line;

typedef struct set
{
	Line* line;
} Set;

typedef struct cache
{
	Set* set;
} Cache;

void getArgs(int, char**);
int square(int);
unsigned long long int myPow(int, int);
unsigned long long int getSet(Address);
void openCache(void);
void insertCache(char, Address, int);
void openTrace(void);
void insert(char, Address, int);
unsigned long long int findLRUIndex(Line*);
void freeCache(void);

int s;
int E;
int b;
char* t;

int S;
int B;

int cacheSize;

int hits = 0, misses = 0, evictions = 0;

Cache mainCache;
Set mainSet;
Line mainLine;

int main(int argc, char** argv)
{
	getArgs(argc, argv);
	openCache();
	openTrace();
	printSummary(hits, misses, evictions);
	freeCache();
	return 0;
}

void getArgs(int argc, char** argv)
{
	char c;

	while((c = getopt(argc, argv, "s:E:b:t")) != -1)
	{
		switch(c)
		{
			case 's':
				s = atoi(optarg);
				break;
			case 'E':
				E = atoi(optarg);
				break;
			case 'b':
				b = atoi(optarg);
				break;
			case 't':
				t = argv[8];	
				break;
		}
	}

	S = square(s);
	B = square(b);
	cacheSize = S*B*E;
}

int square(int base)
{
	return base << 1;
}

unsigned long long int myPow(int base, int exponent)
{
	unsigned long long int ret = 1;
	int i;
	for(i=0; i<exponent; i++)
		ret *= base;
	return ret;
}

unsigned long long int getSet(Address address)
{
	unsigned long long int index = 0;
	Address temp = address >> b;
	index = temp & (myPow(2, b)-1);
	return index;
}

void openCache()
{
	int i, j;
	mainCache.set = (Set*)malloc(sizeof(Set) * S);
	for(i=0; i<S; i++)
	{
		mainSet.line = (Line*)malloc(sizeof(Line) * E);
		mainCache.set[i] = mainSet;
		for(j=0; j<E; j++)
		{
			mainLine.tagBit = 0;
			mainLine.validBit = 0;
			mainLine.isFull = 0;
			mainLine.lru = 0;
			mainSet.line[j] = mainLine;
		}
	}
}

void openTrace()
{
	Address address;
	char mode;
	int size;
	FILE* stream = fopen(t, "r");
	while(fscanf(stream, " %c %llx,%d", &mode, &address, &size) == 3)
		insertCache(mode, address, size);
	fclose(stream);
}

void insertCache(char mode, Address address, int size)
{
	switch(mode)
	{
		case 'I':
			return;
		case 'L':
			insert(mode, address, size);
			break;
		case 'S':
			insert(mode, address, size);
			break;
		case 'M':
			insert(mode, address, size);
			break;
	}
}

void insert(char mode, Address address, int size)
{
	int i, j;
	unsigned long long int setIndex = getSet(address);	
	unsigned long long int tag = address >> (b+s);
	Line temp;
	printf("%c %llx, %d ", mode, address, size);
	for(i=0; i<E; i++)
	{
		if(mainCache.set[setIndex].line[i].isFull == 0)
		{
			printf("miss ");
			temp.tagBit = tag;
			temp.validBit = 1;
			temp.isFull = 1;
			mainCache.set[setIndex].line[i] = temp;
			misses++;
			break;
		}
		else if(mainCache.set[setIndex].line[i].isFull == 1 && mainCache.set[setIndex].line[i].validBit == 1 && mainCache.set[setIndex].line[i].tagBit == tag)
		{
			printf("hit ");
			hits++;
			break;
		}
		else if(i == E-1 && mainCache.set[setIndex].line[i].isFull == 1)
		{
			printf("miss eviction ");
			temp.tagBit = tag;
			temp.validBit = 1;
			temp.isFull = 1;
			mainCache.set[setIndex].line[findLRUIndex(mainCache.set[setIndex].line)] = temp;
			evictions++;
			misses++;
			break;
		}	
		for(j=0; j<E; j++)
		{
			if(mainCache.set[setIndex].line[j].isFull == 1)
				mainCache.set[setIndex].line[j].lru++;
		}
	}
	if(mode == 'M')
	{
		printf("hit");
		hits++;
	}
	printf("\n");
}

unsigned long long int findLRUIndex(Line* lines)
{
	unsigned long long int i;
	for(i=0; i<E; i++)
		if(lines[i].lru == E-1)
			return i;
	return 0;
}

void freeCache()
{/*
	free(mainSet.line);
	free(mainCache.set -> line);
	free(mainCache.set);*/
}